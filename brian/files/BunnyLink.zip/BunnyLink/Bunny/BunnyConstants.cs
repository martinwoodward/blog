﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nabaztag
{
    public class BunnyConstants
    {
        public static readonly string SerialNumber = "INSERT-HERE";
        public static readonly string ApiToken = "INSERT-HERE";
    }
}
