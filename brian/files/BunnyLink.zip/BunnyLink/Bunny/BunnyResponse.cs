﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nabaztag
{
    public class BunnyResponse
    {
        private string message;
        private string comment;

        public BunnyResponse()
        {
            message = "";
            comment = "";
        }

    }
}
