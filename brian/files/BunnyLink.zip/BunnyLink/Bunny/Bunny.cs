﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Web;

namespace Nabaztag
{
    /// <summary>
    ///   Wrapper around the <a href="http://api.nabaztag.com/docs/home.html">Nabaztag API</a>.
    /// </summary>
    public class Bunny
    {
        public static readonly string NABAZTAG_ENDPOINT = "http://api.nabaztag.com/vl/FR/api.jsp";

        public Bunny(string serialNumber, string token)
        {
            this.SerialNumber = serialNumber;
            this.Token = token;
            this.DefaultVoice = "UK-Mistermuggles";
        }

        public void SendMessage(string messageText)
        {
            BunnyMessage message = new BunnyMessage(SerialNumber, Token);
            message.Voice = DefaultVoice;
            message.MessageText = messageText;
            message.TimeToLiveSeconds = 30;

            SendMessage(message);
        }

        public BunnyMessage SendMessage(String messageText, int posLeft, int posRight)
        {
            BunnyMessage message = new BunnyMessage(SerialNumber, Token);
            message.Voice = DefaultVoice;
            message.MessageText = messageText;
            message.PosLeft = posLeft;
            message.PosRight = posRight;
            message.SendEars = true;
            message.TimeToLiveSeconds = 30;

            SendMessage(message);
            return message;
        }

        public void SendMessage(BunnyMessage message)
        {
            Uri uri = new Uri(NABAZTAG_ENDPOINT + "?" +
                message.ToString());

            WebRequest request = WebRequest.Create(uri);
            WebResponse response = request.GetResponse();
            
            response.Close();

            return;
        }


        /// <summary>
        ///  Serial number of the Nabaztag that will receive events
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        ///  The token is a series of digits given when you activate the Nabaztag receiver. 
        ///  This extra identification limits the risks of spam, since, in order to send a
        ///  message, you need to know both the serial number and the token
        /// </summary>
        public string Token { get; set; }

        public string DefaultVoice { get; set; }

    }
    
}
