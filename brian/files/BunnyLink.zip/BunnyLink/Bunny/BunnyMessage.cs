﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Nabaztag
{
    public class BunnyMessage
    {
        public static readonly int DEFAULT_APPLICATION_ID = 42;

        public BunnyMessage(string serialNumber, string token)
        {
            this.SerialNumber = serialNumber;
            this.Token = token;
            this.ApplicationId = BunnyMessage.DEFAULT_APPLICATION_ID;
        }

        public override string ToString()
        {
            // Build up the request string.
            StringBuilder request = new StringBuilder();
            request.AppendFormat("sn={0}&token={1}&idapp={2}", SerialNumber, Token, ApplicationId);
            if (TimeToLiveSeconds > 0)
            {
                request.AppendFormat("&ttlive={0}", TimeToLiveSeconds);
            }
            if (Action > 0)
            {
                request.AppendFormat("&action={0}", Nabcast);
            }
            if (MessageId > 0)
            {
                request.AppendFormat("&idmessage={0}", MessageId);
            }
            if (Nabcast > 0)
            {
                request.AppendFormat("&nabcast={0}", Nabcast);
            }
            if (!String.IsNullOrEmpty(NabcastTitle))
            {
                request.AppendFormat("&nabcasttitle={0}", HttpUtility.UrlEncode(NabcastTitle));
            }
            if (SendEars)
            {
                request.AppendFormat("&posright={0}&posleft={1}&ears=ok", PosRight, PosLeft);
            }
            if (!String.IsNullOrEmpty(ChoreographyName))
            {
                request.AppendFormat("&chortitle={0}", HttpUtility.UrlEncode(ChoreographyName));
            }
            if (!String.IsNullOrEmpty(ChoreographyString))
            {
                request.AppendFormat("&chor={0}", ChoreographyString);
            }
            if (!String.IsNullOrEmpty(Voice))
            {
                request.AppendFormat("&voice={0}", Voice);
            }
            if (!String.IsNullOrEmpty(MessageText))
            {
                request.AppendFormat("&tts={0}", HttpUtility.UrlEncode(MessageText));
            }
            return request.ToString();
        }

        /// <summary>
        ///   Serial number of the Nabaztag that will receive events
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        ///   The token is a series of digits given when you activate the Nabaztag receiver.
        ///   This extra identification limits the risks of spam, since, in order to send a
        ///   message, you need to know both the serial number and the token
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        ///  The number of the message to send. This number can refer to a message in the 
        ///  Library or a personal MP3 file that you have downloaded. You find this 
        ///  identification number under the title of the track you are listening to
        /// </summary>
        public int MessageId { get; set; }

        /// <summary>
        ///   Id of your nabcast (if you want to publish a content in your nabcast)
        /// </summary>
        public int Nabcast { get; set; }

        /// <summary>
        ///   Title of the post in your nabcast
        /// </summary>
        public string NabcastTitle { get; set; }

        /// <summary>
        ///   Position of the right ear between 0 and 16 (0 = ear vertical)
        /// </summary>
        public int PosRight { get; set; }
        
        /// <summary>
        ///   Position of the left ear between 0 and 16 (0 = ear vertical)
        /// </summary>
        public int PosLeft { get; set; }

        /// <summary>
        ///   Send the position of the ears to your Nabaztag
        /// </summary>
        public bool SendEars { get; set; }

        /// <summary>
        ///   This is your application ID.
        ///   It will allow you to authenticate the event's transmitter. 
        ///   Note: This parameter is not yet in service.
        /// </summary>
        public int ApplicationId { get; set; }

        /// <summary>
        ///   Allows you to choose the voice that will read the message
        /// </summary>
        public string Voice { get; set; }

        /// <summary>
        ///   Allows you to send a text configured for speech synthesis
        /// </summary>
        public string MessageText { get; set; }

        /// <summary>
        ///  A choreography string for your Nabaztag
        /// </summary>
        public string ChoreographyString { get; set; }

        /// <summary>
        ///   The name of the choreography
        /// </summary>
        public string ChoreographyName { get; set; }

        /// <summary>
        ///   Allows you to define the length of time you want a message to remain on the site (in seconds). 
        ///   By default, the message will be stored for a period of two months
        /// </summary>
        public int TimeToLiveSeconds { get; set; }

        /// <summary>
        ///   See http://api.nabaztag.com/docs/home.html
        /// </summary>
        public int Action { get; set; }

    }
}
