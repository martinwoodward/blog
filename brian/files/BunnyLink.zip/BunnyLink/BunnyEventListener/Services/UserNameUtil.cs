﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Security.Principal;

namespace BunnyEventListener.Services
{
    public static class UserNameUtil
    {
        private static readonly string ERROR_MESSAGE = "{0} is not a supported user name.";

        /// <summary>
        ///   Convert the name from DOMAIN\name format into name if the
        ///   passed domain is the same as the passed relative -
        ///   otherwise display in the DOMAIN\name format.  This appears
        ///   to be how Team System usually displays names.
        /// </summary>
        public static string GetFriendlyName(string userName, string relative)
        {
            if (string.IsNullOrEmpty(userName))
            {
                return string.Empty;
            }
            if (userName.IndexOf('\\') >= 0)
            {
                string defaultDomain;
                if (relative == null)
                {
                    defaultDomain = DefaultDomain;
                }
                else if (relative.Contains("\\"))
                {
                    defaultDomain = GetDomainName(relative);
                }
                else
                {
                    defaultDomain = relative;
                }
                if ((userName.StartsWith(defaultDomain, StringComparison.OrdinalIgnoreCase) && (userName.Length > (defaultDomain.Length + 1))) && (userName[defaultDomain.Length] == '\\'))
                {
                    return userName.Substring(defaultDomain.Length + 1);
                }
            }
            return userName;
        }

        public static String GetUserName(string userNameAndDomain)
        {
            string name;
            string domain;
            Parse(userNameAndDomain, out name, out domain);
            return name;
        }

        /// <summary>
        ///   Convert a name in DOMAIN\name format into domain and user portions.
        ///   If the name is passed without the domain, then an empty string will
        ///   be returned for the domain portion.
        /// </summary>
        public static void Parse(string userName,
            out string name, out string domain)
        {
            int index = userName.IndexOf('\\');
            if (index < 0)
            {
                // No \ found - assume just passed "username"
                domain = string.Empty;
                name = userName;
            }
            else
            {
                // Found a "\"
                if (index == userName.Length)
                {
                    // Passed something like "DOMAIN\"  No good.
                    throw new ArgumentException(string.Format(ERROR_MESSAGE, userName));
                }
                // Passed "DOMAIN\username" split around the \.
                domain = userName.Substring(0, index);
                name = userName.Substring(index + 1);
            }
        }

        public static string GetDomainName(string userName)
        {
            int index = userName.IndexOf('\\');
            if (index < 0)
            {
                return string.Empty;
            }
            if (index == userName.Length)
            {
                throw new ArgumentException(string.Format(ERROR_MESSAGE, userName));
            }
            return userName.Substring(0, index);
        }

        private static string m_defaultDomain;
        private static string DefaultDomain
        {
            get
            {
                if (m_defaultDomain == null)
                {
                    // Lazily populate the default domain with the domain of
                    // the user underwhich the process is running.
                    string name;
                    string domain;
                    Parse(WindowsIdentity.GetCurrent().Name, out name, out domain);
                    m_defaultDomain = domain;
                }
                return m_defaultDomain;
            }
        }
    }
}
