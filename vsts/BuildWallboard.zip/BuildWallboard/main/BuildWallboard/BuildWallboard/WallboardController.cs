﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Build.Client;

// Build Wallboard sample from TechEd 2007 
//
// TLA316: Code It and Ship It with Team Build 2008
// Brian Randell, Martin Woodward.
// 
// Licensed under the Microsoft Public License (Ms-PL)
// http://www.microsoft.com/resources/sharedsource/licensingbasics/publiclicense.mspx
namespace BuildWallboard
{
  public class WallboardController
  {

    private WallboardForm form;
    private IQueuedBuildsView buildQueue;

    /// <summary>
    ///   Create initial connection to the TFS 2008 Build Server.
    /// </summary>
    public void Connect()
    {
        TeamFoundationServer tfs = new TeamFoundationServer(TfsUrl);

        IBuildServer buildServer = (IBuildServer)tfs.GetService(typeof(IBuildServer));

        buildQueue = buildServer.CreateQueuedBuildsView(TeamProject);
        
        // We are only interested in builds when they are finished or as they are in progress
        buildQueue.StatusFilter = QueueStatus.Completed | QueueStatus.InProgress;

        // Hook up our build queue listener.
        buildQueue.StatusChanged += new StatusChangedEventHandler(buildQueue_StatusChanged);

        // Further Expansion.  Currently when this sample starts and there are no builds in the
        // queue - the initial form is not updated.  It would be nice to detect this and perform a query
        // against TFS to look for Build Details.

        // Note that this API was introduced for the RTM of TFS 2008 and will not work against TFS Beta 2.
        // Code should be something like this...
        //
        // IBuildDetailSpec buildDetailSpec = buildServer.CreateBuildDetailSpec(TeamProject, BuildDefinitionName);
        // buildDetailSpec.MaxBuildsPerDefinition = 1;
        // buildDetailSpec.QueryOrder = BuildQueryOrder.FinishTimeDescending;
 
        // IBuildQueryResult results = buildServer.QueryBuilds(buildDetailSpec);
        // if (results.Builds.Length == 1)
        // {
        //     form.UpdateStatus(results.Builds[0]);
        // }

        // Now connect to the build queue.
        //
        // A poll time of 1 second used for the demo - you might
        // want to reduce this to every 5 minutes if used in the real world.
        buildQueue.Connect(1000, form);
    }

    void buildQueue_StatusChanged(object sender, StatusChangedEventArgs e)
    {
        // Note that despite the name, this method gets called every time the queue is polled.
        form.LastUpdated = DateTime.Now.ToLongTimeString();
        
        // We have to explicitly check to see if the build has changed.
        if (e.Changed && buildQueue.QueuedBuilds.Length > 0)
        {
            // Get the last item (TFS sorts them as we need)
            int lastItem = buildQueue.QueuedBuilds.Length - 1;
            
            // In the session, we showed the results of the last build for the team project.
            // here you may want to filter
            form.UpdateStatus(buildQueue.QueuedBuilds[lastItem]);
        }
    }

    public WallboardController(WallboardForm form)
    {
      this.form = form;
    }

    public string TfsUrl { get; set; }

    public string TeamProject { get; set; }

    public string BuildDefinitionName { get; set; }
    
  }
}
