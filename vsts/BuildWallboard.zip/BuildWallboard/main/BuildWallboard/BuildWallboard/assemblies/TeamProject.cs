﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildWallboard.assemblies
{
    /// <remarks>string</remarks>
    public class TeamProject
    {

        public string TeamProjectName
        {
            get
            {
                return "";
            }
        }

        public List<Microsoft.TeamFoundation.Build.Client.IBuildAgent> BuildAgents
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public List<Microsoft.TeamFoundation.Build.Client.IBuildDefinition> BuildDefinitions
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    
    }

}
