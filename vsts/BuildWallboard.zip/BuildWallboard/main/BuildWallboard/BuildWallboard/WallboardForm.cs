﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.TeamFoundation.Build.Client;

// Build Wallboard sample from TechEd 2007 
//
// TLA316: Code It and Ship It with Team Build 2008
// Brian Randell, Martin Woodward.
// 
// Licensed under the Microsoft Public License (Ms-PL)
// http://www.microsoft.com/resources/sharedsource/licensingbasics/publiclicense.mspx
namespace BuildWallboard
{
  public partial class WallboardForm : Form
  {

    private WallboardController controller;

    public WallboardForm()
    {
        InitializeComponent();
    }

    private void WallboardForm_Load(object sender, EventArgs e)
    {
        controller = new WallboardController(this);
        controller.TfsUrl = "http://tfs08:8080";
        controller.TeamProject = "AdventureWorks";
        controller.BuildDefinitionName = "Wallboard CI";

        controller.Connect();
    }


    private void WallboardForm_MouseClick(object sender, MouseEventArgs e)
    {
      Close();
    }

    public string LastUpdated 
    { 
      set 
      {
        lblLastUpdated.Text = string.Format("Last Updated: {0}", value);
      } 
    }

    public void UpdateStatus(IQueuedBuild queuedBuild)
    {
      if (queuedBuild.Build != null)
      {
        UpdateStatus(queuedBuild.Build);
      }
    }        

    public void UpdateStatus(IBuildDetail detail)
    {
      // We used the build server later to convert the enums into the localized display values.
      IBuildServer buildServer = detail.BuildServer;
      
      lblBuildNumber.Text = detail.BuildNumber;
      
      //  The TFS API's always return DOMAIN\username, however the convention is that we only
      //  display the domain portion if it is different from our current users domain.
      lblRequestedFor.Text = UserNameFormatter.GetFriendlyName(detail.RequestedFor, null);
      
      // If the build has finished then display the finish time.
      lblFinishTime.Text = detail.FinishTime.Equals(DateTime.MinValue) ? 
        "" : detail.FinishTime.ToString();

      // Convert the build status into a localized display text.
      String statusText = buildServer.GetDisplayText(detail.Status);

      // Now we want to show the fancy images.
      switch (detail.Status)
      {
        case BuildStatus.Failed:
          statusPictureBox.Image = global::BuildWallboard.StatusImages.status_bad;
          break;
        case BuildStatus.InProgress:
        case BuildStatus.NotStarted:
          statusPictureBox.Image = global::BuildWallboard.StatusImages.status_queue;
          statusText = buildServer.GetDisplayText(BuildStatus.InProgress);
          break;
        case BuildStatus.PartiallySucceeded:
          statusPictureBox.Image = global::BuildWallboard.StatusImages.status_partial;
          break;
        case BuildStatus.Stopped:
          statusPictureBox.Image = global::BuildWallboard.StatusImages.status_stop;
          break;
        case BuildStatus.Succeeded:
          statusPictureBox.Image = global::BuildWallboard.StatusImages.status_good;
          break;
        default:
          break;
      }
    
      // And finally set the text.
      lblStatus.Text = statusText;

    }
      
  }
}
