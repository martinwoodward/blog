﻿namespace BuildWallboard
{
    partial class WallboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WallboardForm));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblBuildNumber = new System.Windows.Forms.Label();
            this.lblRequestedFor = new System.Windows.Forms.Label();
            this.lblLastUpdated = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.statusPictureBox = new System.Windows.Forms.PictureBox();
            this.lblFinishTime = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Gray;
            this.lblTitle.Location = new System.Drawing.Point(178, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(635, 73);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Current Build Status";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.White;
            this.lblStatus.Location = new System.Drawing.Point(190, 133);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(364, 108);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Waiting";
            // 
            // lblBuildNumber
            // 
            this.lblBuildNumber.AutoSize = true;
            this.lblBuildNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblBuildNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuildNumber.ForeColor = System.Drawing.Color.Gray;
            this.lblBuildNumber.Location = new System.Drawing.Point(222, 254);
            this.lblBuildNumber.Name = "lblBuildNumber";
            this.lblBuildNumber.Size = new System.Drawing.Size(173, 29);
            this.lblBuildNumber.TabIndex = 4;
            this.lblBuildNumber.Text = "{BuildNumber}";
            // 
            // lblRequestedFor
            // 
            this.lblRequestedFor.AutoSize = true;
            this.lblRequestedFor.BackColor = System.Drawing.Color.Transparent;
            this.lblRequestedFor.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequestedFor.ForeColor = System.Drawing.Color.Gray;
            this.lblRequestedFor.Location = new System.Drawing.Point(222, 283);
            this.lblRequestedFor.Name = "lblRequestedFor";
            this.lblRequestedFor.Size = new System.Drawing.Size(186, 29);
            this.lblRequestedFor.TabIndex = 4;
            this.lblRequestedFor.Text = "{RequestedFor}";
            // 
            // lblLastUpdated
            // 
            this.lblLastUpdated.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLastUpdated.BackColor = System.Drawing.Color.Transparent;
            this.lblLastUpdated.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastUpdated.ForeColor = System.Drawing.Color.Gray;
            this.lblLastUpdated.Location = new System.Drawing.Point(-65, 429);
            this.lblLastUpdated.Name = "lblLastUpdated";
            this.lblLastUpdated.Size = new System.Drawing.Size(878, 29);
            this.lblLastUpdated.TabIndex = 4;
            this.lblLastUpdated.Text = "{LastUpdated}";
            this.lblLastUpdated.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BuildWallboard.StatusImages.company_logo;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(160, 100);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // statusPictureBox
            // 
            this.statusPictureBox.Image = global::BuildWallboard.StatusImages.status_good;
            this.statusPictureBox.InitialImage = global::BuildWallboard.StatusImages.status_good;
            this.statusPictureBox.Location = new System.Drawing.Point(44, 133);
            this.statusPictureBox.Name = "statusPictureBox";
            this.statusPictureBox.Size = new System.Drawing.Size(128, 256);
            this.statusPictureBox.TabIndex = 0;
            this.statusPictureBox.TabStop = false;
            // 
            // lblFinishTime
            // 
            this.lblFinishTime.AutoSize = true;
            this.lblFinishTime.BackColor = System.Drawing.Color.Transparent;
            this.lblFinishTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinishTime.ForeColor = System.Drawing.Color.Gray;
            this.lblFinishTime.Location = new System.Drawing.Point(222, 312);
            this.lblFinishTime.Name = "lblFinishTime";
            this.lblFinishTime.Size = new System.Drawing.Size(152, 29);
            this.lblFinishTime.TabIndex = 4;
            this.lblFinishTime.Text = "{FinishTime}";
            // 
            // WallboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(825, 467);
            this.Controls.Add(this.lblLastUpdated);
            this.Controls.Add(this.lblRequestedFor);
            this.Controls.Add(this.lblFinishTime);
            this.Controls.Add(this.lblBuildNumber);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.statusPictureBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WallboardForm";
            this.Text = "Build Wallboard";
            this.Load += new System.EventHandler(this.WallboardForm_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.WallboardForm_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox statusPictureBox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblBuildNumber;
        private System.Windows.Forms.Label lblRequestedFor;
        private System.Windows.Forms.Label lblLastUpdated;
        private System.Windows.Forms.Label lblFinishTime;
    }
}

