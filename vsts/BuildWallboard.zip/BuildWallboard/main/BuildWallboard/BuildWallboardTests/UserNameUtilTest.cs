﻿using BuildWallboard;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Principal;

// Build Wallboard sample from TechEd 2007 
//
// TLA316: Code It and Ship It with Team Build 2008
// Brian Randell, Martin Woodward.
// 
// Licensed under the Microsoft Public License (Ms-PL)
// http://www.microsoft.com/resources/sharedsource/licensingbasics/publiclicense.mspx
namespace BuildWallboardTests
{
    
    
  [TestClass()]
  public class UserNameUtilTest
  {

    [TestMethod()]
    public void ParseTestStandardNT()
    {
      string nameExpected = "foo";
      string domainExpected = "BAR";

      string name;
      string domain;
      UserNameFormatter.Parse(@"BAR\foo", out name, out domain);

      Assert.AreEqual(nameExpected, name);
      Assert.AreEqual(domainExpected, domain);
    }

    [TestMethod()]
    public void ParseTestNoDomain()
    {
      string nameExpected = "foobar";
      string domainExpected = string.Empty;

      string name;
      string domain;
      UserNameFormatter.Parse("foobar", out name, out domain);

      Assert.AreEqual(nameExpected, name);
      Assert.AreEqual(domainExpected, domain);
    }

    [TestMethod()]
    public void GetDomainNameTest()
    {
      string expected = "BAR";
      string actual;
      actual = UserNameFormatter.GetDomainName("BAR\\foo");
      Assert.AreEqual(expected, actual);
    }

    [TestMethod()]
    public void GetDomainNameTestNoDomain()
    {
      string expected = string.Empty;
      string actual;
      actual = UserNameFormatter.GetDomainName("foobar");
      Assert.AreEqual(expected, actual);
    }

    [TestMethod()]
    public void GetFriendlyNameTestSameDomain()
    {
      string expected = "foo"; 
      string actual;
      actual = UserNameFormatter.GetFriendlyName("BAR\\foo", "BAR");
      Assert.AreEqual(expected, actual);
    }

    [TestMethod()]
    public void GetFriendlyNameTestDifferentDomain()
    {
      string expected = "BAR\\foo";
      string actual;
      actual = UserNameFormatter.GetFriendlyName("BAR\\foo", "RAB");
      Assert.AreEqual(expected, actual);
    }

    [TestMethod()]
    public void GetFriendlyNameTestCurrentDomain()
    {
      string currentUser = WindowsIdentity.GetCurrent().Name;
      string domain;
      string expected;
      UserNameFormatter.Parse(currentUser, out expected, out domain);
      string actual = UserNameFormatter.GetFriendlyName(currentUser, null);
      Assert.AreEqual(expected, actual);
    }



    private TestContext testContextInstance;

    /// <summary>
    ///Gets or sets the test context which provides
    ///information about and functionality for the current test run.
    ///</summary>
    public TestContext TestContext
    {
      get
      {
        return testContextInstance;
      }
      set
      {
        testContextInstance = value;
      }
    }

    #region Additional test attributes
    // 
    //You can use the following additional attributes as you write your tests:
    //
    //Use ClassInitialize to run code before running the first test in the class
    //[ClassInitialize()]
    //public static void MyClassInitialize(TestContext testContext)
    //{
    //}
    //
    //Use ClassCleanup to run code after all tests in a class have run
    //[ClassCleanup()]
    //public static void MyClassCleanup()
    //{
    //}
    //
    //Use TestInitialize to run code before running each test
    //[TestInitialize()]
    //public void MyTestInitialize()
    //{
    //}
    //
    //Use TestCleanup to run code after each test has run
    //[TestCleanup()]
    //public void MyTestCleanup()
    //{
    //}
    //
    #endregion

  
  }
}
